import React, { useState, useEffect, useCallback } from 'react'
import styles from './SyncPanel.module.scss'

const chromeRuntime = () => typeof chrome !== 'undefined' && chrome.runtime

function sendToWorker(type, payload = {}) {
  return new Promise((resolve) => {
    if (!chromeRuntime()) return resolve(null)
    chrome.runtime.sendMessage({ type, payload }, (response) => {
      if (chrome.runtime.lastError) return resolve(null)
      resolve(response)
    })
  })
}

export default function SyncPanel({ url, secretKey, jiraBaseUrl, jiraJqlQuery, sheetId, sheetName }) {
  const [loading, setLoading]               = useState(false)
  const [activeOperation, setActiveOperation] = useState('')
  const [syncProgress, setSyncProgress]     = useState(0)
  const [syncStatus, setSyncStatus]         = useState('')
  const [result, setResult]                 = useState(null)
  const [syncStats, setSyncStats]           = useState(null)
  const [archiveStats, setArchiveStats]     = useState(null)
  const [detectedDates, setDetectedDates]   = useState([])
  const [cookieFound, setCookieFound]       = useState(null)

  // Hydrate from persisted worker state when popup opens
  useEffect(() => {
    if (!chromeRuntime()) return

    sendToWorker('GET_SYNC_STATE').then((state) => {
      if (!state) return
      if (state.running) {
        setLoading(true)
        setActiveOperation(state.operation || 'sync')
        setSyncProgress(state.progress || 0)
        setSyncStatus(state.status || 'Syncing…')
        if (state.dates) setDetectedDates(state.dates)
        if (state.cookieFound != null) setCookieFound(state.cookieFound)
      } else if (state.result) {
        applyResult(state.result)
      }
    })

    // Listen for live updates from the worker
    const onMessage = (message) => {
      if (message.type === 'SYNC_PROGRESS') {
        const { progress, status, dates, cookieFound: cf, operation } = message.payload
        setActiveOperation(operation || 'sync')
        setSyncProgress(progress)
        setSyncStatus(status)
        if (dates) setDetectedDates(dates)
        if (cf != null) setCookieFound(cf)
      } else if (message.type === 'SYNC_COMPLETE') {
        setLoading(false)
        setActiveOperation('')
        setSyncProgress(0)
        setSyncStatus('')
        applyResult(message.payload)
      }
    }

    chrome.runtime.onMessage.addListener(onMessage)
    return () => chrome.runtime.onMessage.removeListener(onMessage)
  }, [])

  function applyResult(payload) {
    const operation = payload.result?.operation || payload.operation || 'sync'
    if (payload.success) {
      if (operation === 'archive') {
        setArchiveStats(payload.result?.stats ?? payload.stats ?? null)
      } else {
        setSyncStats(payload.result?.stats ?? payload.stats ?? null)
      }
      setResult({
        success: true,
        operation,
        message: payload.result?.message ?? payload.message ?? (operation === 'archive' ? 'Archive complete' : 'Sync complete'),
      })
    } else if (payload.success === false) {
      setResult({ success: false, operation, error: payload.error, code: payload.code })
    }
  }

  const isJiraConfigured = !!(jiraBaseUrl && url)

  const doJiraSync = useCallback(async () => {
    if (!isJiraConfigured || loading) return
    setLoading(true)
    setActiveOperation('sync')
    setResult(null)
    setSyncStats(null)
    setSyncProgress(0)
    setSyncStatus('Starting sync…')
    setDetectedDates([])
    setCookieFound(null)

    const response = await sendToWorker('START_SYNC', { url, secretKey, jiraBaseUrl, jiraJqlQuery, sheetId, sheetName })
    if (!response?.ok) {
      setLoading(false)
      setActiveOperation('')
      const reason = response?.reason === 'already_running'
        ? 'A sync is already running.'
        : 'Could not reach background worker.'
      setResult({ success: false, error: reason })
    }
  }, [isJiraConfigured, loading, url, secretKey, jiraBaseUrl, jiraJqlQuery, sheetId, sheetName])

  const doArchive = useCallback(async () => {
    if (!isJiraConfigured || loading) return
    setLoading(true)
    setActiveOperation('archive')
    setResult(null)
    setArchiveStats(null)
    setSyncProgress(0)
    setSyncStatus('Preparing archive…')
    setDetectedDates([])
    setCookieFound(null)

    const response = await sendToWorker('START_ARCHIVE', { url, secretKey, sheetId, sheetName })
    if (!response?.ok) {
      setLoading(false)
      setActiveOperation('')
      const reason = response?.reason === 'already_running'
        ? 'An operation is already running.'
        : 'Could not reach background worker.'
      setResult({ success: false, operation: 'archive', error: reason })
    }
  }, [isJiraConfigured, loading, url, secretKey, sheetId, sheetName])

  const cookieClass =
    cookieFound === true  ? styles.cookieFound  :
    cookieFound === false ? styles.cookieMissing :
    styles.cookieUnknown

  const cookieText =
    cookieFound === true  ? '✓ found'       :
    cookieFound === false ? '✕ not found'   :
    '— checked on sync'

  return (
    <div className={styles.wrap}>

      {/* Config card */}
      {isJiraConfigured ? (
        <div className={styles.configCard}>
          <div className={styles.configRow}>
            <span className={styles.configLabel}>JIRA URL</span>
            <span className={`${styles.configVal} ${styles.configValAccent}`}>{jiraBaseUrl}</span>
          </div>
          <div className={styles.configRow}>
            <span className={styles.configLabel}>Dates from</span>
            <span className={styles.configVal}>column A of sheet</span>
          </div>
          <div className={styles.configRow}>
            <span className={styles.configLabel}>Timezone</span>
            <span className={styles.configVal}>America/New_York (EST)</span>
          </div>
          <div className={styles.configRow}>
            <span className={styles.configLabel}>JSESSIONID</span>
            <span className={`${styles.configVal} ${cookieClass}`}>{cookieText}</span>
          </div>
          <div className={styles.configRow}>
            <span className={styles.configLabel}>Sheet</span>
            <span className={styles.configVal}>
              {sheetId ? `…${sheetId.slice(-8)}` : 'Script\'s own sheet'}
            </span>
          </div>
          <div className={styles.configRow}>
            <span className={styles.configLabel}>Tab</span>
            <span className={styles.configVal}>
              {sheetName || 'First visible tab'}
            </span>
          </div>
          <div className={styles.divider} />
          <div className={styles.jqlLabel}>JQL Template</div>
          <div className={styles.jqlBlock}>
            {jiraJqlQuery?.trim()
              ? jiraJqlQuery.trim()
              : <span className={styles.jqlDefault}>{'due="{date}" ORDER BY created ASC (default)'}</span>
            }
          </div>
        </div>
      ) : (
        <div className={styles.warning}>
          ⚠ JIRA Base URL or Web App URL not configured.
          <br />
          Open ⚙ Preferences to set them up.
        </div>
      )}

      {/* Detected dates */}
      {detectedDates.length > 0 && (
        <div className={styles.datesWrap}>
          <div className={styles.datesLabel}>Dates found in column A</div>
          <div className={styles.pills}>
            {detectedDates.map((d) => (
              <span key={d} className={styles.pill}>{d}</span>
            ))}
          </div>
        </div>
      )}

      {/* Progress */}
      {loading && syncStatus && (
        <div className={styles.progressWrap}>
          <div className={styles.progressStatus}>{syncStatus}</div>
          <div className={styles.progressBar}>
            <div className={styles.progressFill} style={{ width: `${syncProgress}%` }} />
          </div>
        </div>
      )}

      {/* Background-sync banner */}
      {loading && (
        <div className={styles.bgWarning}>
          <span className={styles.bgWarningIcon}>⟳</span>
          <span>
            {activeOperation === 'archive' ? 'Archive is running in the background' : 'Sync is running in the background'} — safe to close this popup.
            Watch the extension icon for live status.
          </span>
        </div>
      )}

      {/* Action buttons */}
      <button
        className={`${styles.syncBtn} ${(!isJiraConfigured || loading) ? styles.syncBtnDisabled : ''}`}
        onClick={doJiraSync}
        disabled={!isJiraConfigured || loading}
      >
        {loading && activeOperation === 'sync' ? '⟳ Syncing…' : '⟳ Sync from JIRA'}
      </button>

      <button
        className={`${styles.archiveBtn} ${(!isJiraConfigured || loading) ? styles.archiveBtnDisabled : ''}`}
        onClick={doArchive}
        disabled={!isJiraConfigured || loading}
      >
        {loading && activeOperation === 'archive' ? '⟳ Archiving…' : 'Archive'}
      </button>

      {/* Stats */}
      {syncStats && (
        <div className={styles.statsCard}>
          <div className={styles.statsTitle}>Sync results</div>
          <div className={styles.statsRow}>
            <span className={styles.statsLabel}>Inserted</span>
            <span className={`${styles.statsVal} ${styles.statsValSuccess}`}>{syncStats.inserted ?? 0}</span>
          </div>
          <div className={styles.statsRow}>
            <span className={styles.statsLabel}>Updated</span>
            <span className={`${styles.statsVal} ${styles.statsValWarning}`}>{syncStats.updated ?? 0}</span>
          </div>
          <div className={styles.statsRow}>
            <span className={styles.statsLabel}>Moved</span>
            <span className={`${styles.statsVal} ${styles.statsValMoved}`}>{syncStats.moved ?? 0}</span>
          </div>
          <div className={styles.statsRow}>
            <span className={styles.statsLabel}>Skipped</span>
            <span className={styles.statsVal}>{syncStats.skipped ?? 0}</span>
          </div>
          {syncStats.perDate?.length > 0 && (
            <>
              <div className={styles.divider} />
              {syncStats.perDate.map((pd, i) => (
                <div key={i} className={styles.perDateRow}>
                  <span className={styles.perDateKey}>{pd.date}</span>
                  <span>{pd.issues ?? 0} issues</span>
                </div>
              ))}
            </>
          )}
        </div>
      )}

      {archiveStats && (
        <div className={styles.statsCard}>
          <div className={styles.statsTitle}>Archive results</div>
          <div className={styles.statsRow}>
            <span className={styles.statsLabel}>Archived</span>
            <span className={styles.statsVal}>{archiveStats.archivedCount ?? 0}</span>
          </div>
          <div className={styles.statsRow}>
            <span className={styles.statsLabel}>Rolled Back</span>
            <span className={styles.statsVal}>{archiveStats.rollbackMoved ?? 0}</span>
          </div>
          {(archiveStats.rollbackWarnings?.length ?? 0) > 0 && (
            <>
              <div className={styles.divider} />
              {archiveStats.rollbackWarnings.map((w, i) => (
                <div key={`archive-warn-${i}`} className={styles.perDateRow}>
                  <span className={styles.perDateKey}>Archive warning</span>
                  <span>{w}</span>
                </div>
              ))}
            </>
          )}
        </div>
      )}

      {/* Result messages */}
      {result?.success && (
        <div className={styles.successMsg}>
          <span>✓ {result.message}</span>
          <button className={styles.dismissBtn} onClick={() => setResult(null)}>✕</button>
        </div>
      )}
      {result && !result.success && (
        <div className={`${styles.errorMsg} ${(result.code === 401 || result.code === 403) ? styles.errorMsgAuth : styles.errorMsgNetwork}`}>
          <span className={styles.errorTitle}>
            {result.code ? `${result.code} Error` : 'Error'}
          </span>
          {result.error}
        </div>
      )}
    </div>
  )
}
