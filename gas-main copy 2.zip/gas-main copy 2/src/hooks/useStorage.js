import { useState, useEffect, useCallback } from 'react'

const STORAGE_KEY = 'gas_trigger_preferences'

const defaultPrefs = {
  url: 'https://script.google.com/a/macros/verizon.com/s/AKfycbyBXAxkXjNS4Yp36xISV8uFNjzk45GWjreRowE167Xb9IHHaM42sj2cIuVuyE_ghoIsqw/exec',
  lastUsed: null,
  secretKey: '1234567890',
  jiraBaseUrl: 'https://onejira.verizon.com',
  jiraJqlQuery: 'project = DOPMO AND (component in ("DIGOPS/FED","DIGOPS/FED_Tactical", "DIGOPS/FED_Strategic","DIGOPS/FED_DigitalComponents", "DIGOPS/FED_Projects", "DIGOPS/FED_ACT", "DIGOPS/FED_OpEx", "DIGOPS/FED_Engineering") OR (labels in ("FED_REV","FED_IMPL","FED_NO_IMPL","FED_REQ_GAP","FED_PUB","FED_CacheCLR", "FED_Triaged"))) AND due = "{date}" ORDER BY created ASC',
  sheetId: '1UOMEkUpcukcOBrtXAaO2gZ3hF9KX1KQzNiTEpI432qI'
}

const storage = {
  get(key) {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      return new Promise((resolve) => {
        chrome.storage.sync.get([key], (result) => resolve(result[key]))
      })
    }
    try {
      const val = localStorage.getItem(key)
      return Promise.resolve(val ? JSON.parse(val) : undefined)
    } catch {
      return Promise.resolve(undefined)
    }
  },

  set(key, value) {
    if (typeof chrome !== 'undefined' && chrome.storage) {
      return new Promise((resolve) => {
        chrome.storage.sync.set({ [key]: value }, resolve)
      })
    }
    try {
      localStorage.setItem(key, JSON.stringify(value))
      return Promise.resolve()
    } catch {
      return Promise.resolve()
    }
  },
}

export function useStorage() {
  const [prefs, setPrefsState] = useState(defaultPrefs)
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    storage.get(STORAGE_KEY).then((saved) => {
      if (saved) setPrefsState((prev) => ({ ...prev, ...saved }))
      setLoaded(true)
    })
  }, [])

  const setPrefs = useCallback(async (updates) => {
    const next = typeof updates === 'function' ? updates(prefs) : { ...prefs, ...updates }
    setPrefsState(next)
    await storage.set(STORAGE_KEY, next)
  }, [prefs])

  const saveLastUsed = useCallback(
    () => setPrefs({ lastUsed: new Date().toISOString() }),
    [setPrefs]
  )

  return { prefs, loaded, saveLastUsed, setPrefs }
}
