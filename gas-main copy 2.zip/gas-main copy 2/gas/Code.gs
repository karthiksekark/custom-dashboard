// ============================================================
//  GAS Trigger — Google Apps Script Backend  v6
//  Deploy as Web App: Execute as Me | Access: Anyone
//  Secret key: GET ?key=<val>  |  POST body.key
// ============================================================

const SECRET_KEY        = '1234567890'
const COLUMNS           = ['Ticket Number', 'Title', 'Status', 'Parent Ticket Number', 'Fix Version', 'Due Date', 'Content Release Paths', 'Launches', 'Comments']
const TICKET_IDX        = 0
const TITLE_IDX         = 1
const STATUS_IDX        = 2
const PARENT_IDX        = 3
const FIXVER_IDX        = 4
const DUEDATE_IDX       = 5
const CRPATHS_IDX       = 6
const LAUNCHES_IDX      = 7
const COMMENTS_IDX      = 8
const JIRA_COL_COUNT    = 9   // A–I

// Title column width + columns that should auto-fit their content
const TITLE_COL_WIDTH   = 300
const AUTOFIT_IDXS      = [TICKET_IDX, STATUS_IDX, PARENT_IDX, FIXVER_IDX, DUEDATE_IDX]

// Columns with a fixed 300px width and no text wrap
const FIXED_COL_WIDTH   = 300
const FIXED_CLIP_IDXS   = [CRPATHS_IDX, LAUNCHES_IDX]
const FIXED_NOWRAP_IDXS = [COMMENTS_IDX]

// Date row styling
const DATE_ROW_BG    = '#fff9c4'   // yellow — cols A–E on date rows
const DATE_LABEL_COL = 2           // col B — time/regular label
const LEGACY_DATE_LABEL_COL = 3    // col C — legacy label location
const DATE_COUNT_COL = 4           // col D — ticket count
const DATE_FONT_CLR  = '#b8860b'   // dark amber text on date rows
const BLOCK_LABEL_REGULAR = 'Regular Block'
const BLOCK_TYPE_TIME = 'TIME'
const BLOCK_TYPE_REGULAR = 'REGULAR'

// Header row styling
const HDR_BG         = '#4f6ef7'
const HDR_FG         = '#ffffff'

const BLANK_VAL  = '—'
const DUP_SUFFIX = ' modified'
const JIRA_BASE_URL = 'https://onejira.verizon.com'
const ARCHIVE_SHEET_NAME = 'Archive'

// Per-request spreadsheet context — populated by doGet/doPost from incoming params.
var _spreadsheetId = null
var _sheetName     = null

// ── Responses ──
function respond(d) {
  return ContentService.createTextOutput(JSON.stringify(d))
    .setMimeType(ContentService.MimeType.JSON)
}
function unauth()    { return respond({ success:false, error:'Unauthorized', code:401 }) }
function badReq(m)   { return respond({ success:false, error:m||'Bad Request', code:400 }) }
function srvErr(m)   { return respond({ success:false, error:m||'Server Error', code:500 }) }
function ok(d)       { return respond(Object.assign({ success:true }, d)) }

function validateKey(k) { return k === SECRET_KEY }

// Opens the spreadsheet referenced by the request, or the bound one as fallback.
function getSpreadsheet() {
  return _spreadsheetId
    ? SpreadsheetApp.openById(_spreadsheetId)
    : SpreadsheetApp.getActiveSpreadsheet()
}

// Returns only non-hidden sheets, preserving their left-to-right order.
function getVisibleSheets() {
  return getSpreadsheet().getSheets().filter(function(s) {
    return !s.isSheetHidden()
  })
}

// Targets the tab named _sheetName, or the first visible tab when _sheetName is unset.
function getSheet() {
  var sheets = getVisibleSheets()
  if (!sheets.length) throw new Error('No visible sheets found in spreadsheet')
  if (_sheetName) {
    var match = sheets.filter(function(s) { return s.getName() === _sheetName })
    if (!match.length) throw new Error('Tab "' + _sheetName + '" not found or is hidden')
    return match[0]
  }
  return sheets[0]
}

// ── Date parsing → M/D/YYYY or null ──
// Cached per-request so getSpreadsheetTimeZone() is only called once.
var _sheetTz = null
function sheetTimezone() {
  if (!_sheetTz) _sheetTz = getSpreadsheet().getSpreadsheetTimeZone()
  return _sheetTz
}

function parseDate(val) {
  if (!val && val !== 0) return null
  if (val instanceof Date) {
    if (isNaN(val.getTime())) return null
    // getDate()/getMonth()/getFullYear() are UTC-based in GAS. For spreadsheets
    // in timezones ahead of UTC, midnight local time is the previous UTC day,
    // causing an off-by-one. Utilities.formatDate respects the spreadsheet TZ.
    var s = Utilities.formatDate(val, sheetTimezone(), 'M/d/yyyy')
    var mp = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/)
    if (!mp || +mp[1]<1||+mp[1]>12||+mp[2]<1||+mp[2]>31||+mp[3]<2000) return null
    return +mp[1]+'/'+mp[2]+'/'+mp[3]
  }
  var s = String(val).trim()
  var m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/)
  if (m && +m[1]>=1&&+m[1]<=12&&+m[2]>=1&&+m[2]<=31&&+m[3]>=2000)
    return +m[1]+'/'+m[2]+'/'+m[3]
  var y = s.match(/^(\d{4})-(\d{2})-(\d{2})$/)
  if (y && +y[2]>=1&&+y[2]<=12&&+y[3]>=1&&+y[3]<=31&&+y[1]>=2000)
    return +y[2]+'/'+y[3]+'/'+y[1]
  return null
}

// ── Style helpers ──

// Date row: full A–E yellow bg, time label in B (blank for regular block), "Total Tickets" in C, count in D
function styleDateRow(sheet, row, count, dateLabel) {
  // Clear full row formatting first
  sheet.getRange(row, 1, 1, JIRA_COL_COUNT)
       .setBackground(DATE_ROW_BG)
       .setFontColor(DATE_FONT_CLR)
       .setFontWeight('bold')
       .setHorizontalAlignment('left')

  // Col A — date value already there, just style
  // Col B — show time label; keep empty for regular blocks.
  var normalizedLabel = String(dateLabel || '').trim()
  var bLabel = (!normalizedLabel || normalizedLabel.toLowerCase() === BLOCK_LABEL_REGULAR.toLowerCase() || normalizedLabel.toLowerCase() === 'total tickets')
    ? ''
    : normalizedLabel
  sheet.getRange(row, DATE_LABEL_COL).setValue(bLabel)
  // Col C — keep legacy "Total Tickets" text for compatibility.
  sheet.getRange(row, LEGACY_DATE_LABEL_COL).setValue('Total Tickets')
  // Col D — count; explicitly plain-number format so the date-formatted column
  // doesn't render e.g. 3 as "1/3/1900".
  sheet.getRange(row, DATE_COUNT_COL).setNumberFormat('0').setValue(count)
  // Col E — empty, already styled above
}

function readDateRowLabelFromRow(rowVals) {
  var primary = String(rowVals[DATE_LABEL_COL - 1] || '').trim()
  if (primary) return primary
  return String(rowVals[LEGACY_DATE_LABEL_COL - 1] || '').trim()
}

function readDateRowLabel(sheet, row) {
  var vals = sheet.getRange(row, 1, 1, Math.max(DATE_COUNT_COL, LEGACY_DATE_LABEL_COL)).getValues()[0]
  return readDateRowLabelFromRow(vals)
}

function parseDisplayTimeLabel(label) {
  var raw = String(label || '').trim()
  if (!raw) return null
  var m = raw.match(/^(\d{1,2})(?::(\d{2}))?\s*(AM|PM)\s*ET$/i)
  if (!m) return null
  var hour = +m[1]
  var minute = m[2] ? +m[2] : 0
  if (hour < 1 || hour > 12 || minute < 0 || minute > 59) return null
  var mer = m[3].toUpperCase()
  var h24 = mer === 'AM' ? (hour === 12 ? 0 : hour) : (hour === 12 ? 12 : hour + 12)
  var sortKey = h24 * 60 + minute
  var normalized = m[2]
    ? (hour + ':' + String(minute).padStart(2, '0') + ' ' + mer + ' ET')
    : (hour + mer + ' ET')
  return { label: normalized, sortKey: sortKey }
}

function normalizeBlockType(type) {
  return String(type || '').toUpperCase() === BLOCK_TYPE_TIME ? BLOCK_TYPE_TIME : BLOCK_TYPE_REGULAR
}

function blockMetaFromDateLabel(label) {
  var raw = String(label || '').trim()
  if (!raw || raw.toLowerCase() === 'total tickets' || raw.toLowerCase() === BLOCK_LABEL_REGULAR.toLowerCase()) {
    return { blockType: BLOCK_TYPE_REGULAR, blockLabel: BLOCK_LABEL_REGULAR, sortKey: 999999 }
  }
  var parsed = parseDisplayTimeLabel(raw)
  if (parsed) {
    return { blockType: BLOCK_TYPE_TIME, blockLabel: parsed.label, sortKey: parsed.sortKey }
  }
  // Legacy labels from previous AM/PM split rollout.
  var lower = raw.toLowerCase()
  if (lower.indexOf('am block') !== -1) {
    return { blockType: BLOCK_TYPE_TIME, blockLabel: '12AM ET', sortKey: 0 }
  }
  if (lower.indexOf('pm block') !== -1) {
    return { blockType: BLOCK_TYPE_TIME, blockLabel: '12PM ET', sortKey: 720 }
  }
  return { blockType: BLOCK_TYPE_REGULAR, blockLabel: BLOCK_LABEL_REGULAR, sortKey: 999999 }
}

function normalizeBlockLabel(type, label) {
  var blockType = normalizeBlockType(type)
  if (blockType === BLOCK_TYPE_REGULAR) return BLOCK_LABEL_REGULAR
  var parsed = parseDisplayTimeLabel(label)
  return parsed ? parsed.label : BLOCK_LABEL_REGULAR
}

function blockSortRank(meta) {
  if (meta.blockType === BLOCK_TYPE_TIME) return meta.sortKey
  return 1000000
}

function blockKey(dateStr, blockType, blockLabel) {
  return String(dateStr || '') + '::' + normalizeBlockType(blockType) + '::' + normalizeBlockLabel(blockType, blockLabel)
}

function collectDateBlocks(sheet) {
  var out = []
  var lr = sheet.getLastRow()
  if (!lr) return out
  var vals = sheet.getRange(1, 1, lr, DATE_COUNT_COL).getValues()
  for (var i = 0; i < vals.length; i++) {
    var d = parseDate(vals[i][0])
    if (!d) continue
    var meta = blockMetaFromDateLabel(readDateRowLabelFromRow(vals[i]))
    out.push({
      date: d,
      row: i + 1,
      blockType: meta.blockType,
      blockLabel: meta.blockLabel,
      sortKey: meta.sortKey,
    })
  }
  return out
}

// Header row: blue bg, white bold text + Categorize checkbox in col H
function styleHeader(sheet, row) {
  sheet.getRange(row, 1, 1, JIRA_COL_COUNT)
       .setValues([COLUMNS])
       .setBackground(HDR_BG)
       .setFontColor(HDR_FG)
       .setFontWeight('bold')
       .setHorizontalAlignment('left')
       .setVerticalAlignment('middle')
}

// Clear data row formatting (no background, default text)
function clearRowStyle(sheet, row, numCols) {
  sheet.getRange(row, 1, 1, numCols || JIRA_COL_COUNT)
       .setBackground(null)
       .setFontColor(null)
       .setFontWeight('normal')
       .setHorizontalAlignment('left')
       .setVerticalAlignment('top')
}

// ── Sheet scanning ──

function getAllDates(sheet) {
  var lr = sheet.getLastRow()
  if (!lr) return []
  var vals = sheet.getRange(1,1,lr,1).getValues()
  var seen={}, out=[]
  for (var i=0;i<vals.length;i++) {
    var p=parseDate(vals[i][0])
    if (p&&!seen[p]) { seen[p]=true; out.push(p) }
  }
  return out
}

function rowsForDate(colAVals, dateStr) {
  var out=[]
  for (var i=0;i<colAVals.length;i++)
    if (parseDate(colAVals[i][0])===dateStr) out.push(i+1)
  return out
}

// Block: rows from triggerRow+2 (after header) to next date row-1 or lastRow
function blockBounds(triggerRow, colAVals, lastRow) {
  var s=triggerRow+2, e=lastRow
  for (var r=s;r<=lastRow;r++)
    if (r-1<colAVals.length&&parseDate(colAVals[r-1][0])!==null){e=r-1;break}
  return {start:s, end:e}
}

// Read block → { map: ticket→{rowNum,jiraVals,fullRow}, lastReal }
function readBlock(sheet, s, e, triggerRow) {
  var map={}, lastReal=triggerRow+1
  if (s>e) return {map:map, lastReal:lastReal}
  var lc=Math.max(sheet.getLastColumn(), JIRA_COL_COUNT)
  var rows=sheet.getRange(s,1,e-s+1,lc).getValues()
  for (var i=0;i<rows.length;i++) {
    var tk=String(rows[i][TICKET_IDX]||'').trim()
    var ti=String(rows[i][TITLE_IDX] ||'').trim()
    if (!tk||ti===BLANK_VAL||ti===''||ti.toLowerCase()==='title') continue
    map[tk]={rowNum:s+i, jiraVals:rows[i].slice(0,JIRA_COL_COUNT), fullRow:rows[i]}
    lastReal=s+i
  }
  return {map:map, lastReal:lastReal}
}

function headerExists(sheet, triggerRow) {
  if (triggerRow >= sheet.getLastRow()) return false
  // Check col A only so that old 5-column headers are still recognised as
  // headers and migrated in-place by styleHeader (which writes all COLUMNS).
  var first = String(sheet.getRange(triggerRow + 1, 1).getValue() || '').toLowerCase().trim()
  return first === COLUMNS[TICKET_IDX].toLowerCase()
}

function countRealInBlock(sheet, triggerRow) {
  var lr = sheet.getLastRow()
  // Block data starts at triggerRow+2 if header exists, else triggerRow+1
  var s = headerExists(sheet, triggerRow) ? triggerRow + 2 : triggerRow + 1
  if (s > lr) return 0
  var e = lr
  // Batch-read colA from s to find next date row boundary
  var cA = sheet.getRange(s, 1, lr - s + 1, 1).getValues()
  for (var i = 0; i < cA.length; i++) {
    if (parseDate(cA[i][0]) !== null) { e = s + i - 1; break }
  }
  if (e < s) return 0
  var v = sheet.getRange(s, TITLE_IDX + 1, e - s + 1, 1).getValues()
  var n = 0
  for (var i = 0; i < v.length; i++) {
    var t = String(v[i][0] || '').trim()
    if (t && t !== BLANK_VAL && t.toLowerCase() !== 'title') n++
  }
  return n
}

// ── Path splitting ──
// Splits a newline-delimited string of paths into two groups:
//   crp     — paths that do NOT contain /launches/  → Content Release Paths col
//   launches — paths that DO contain /launches/     → Launches col
function splitPaths(raw) {
  var paths = String(raw || '').split('\n')
    .map(function(p) { return p.trim() })
    .filter(function(p) { return p !== '' })
  var crp = [], launches = []
  paths.forEach(function(p) {
    if (p.indexOf('/launches/') !== -1) launches.push(p)
    else crp.push(p)
  })
  return { crp: crp.join('\n'), launches: launches.join('\n') }
}

// Write HYPERLINK formula in col A, setValue for B–G (skip Comments — user managed)
function writeTicketFormula(sheet, row, ticketKey) {
  if (!ticketKey) return
  sheet.getRange(row, TICKET_IDX+1)
       .setFormula('=HYPERLINK("'+JIRA_BASE_URL+'/browse/'+ticketKey+'","'+ticketKey+'")')
}

// Write HYPERLINK formula for the parent ticket, or clear the cell if there is none.
function writeParentFormula(sheet, row, parentKey) {
  var cell = sheet.getRange(row, PARENT_IDX+1)
  if (!parentKey) { cell.clearContent(); return }
  cell.setFormula('=HYPERLINK("'+JIRA_BASE_URL+'/browse/'+parentKey+'","'+parentKey+'")')
}

// Title column: fixed width + wrap. Ticket/Status/Parent/Fix Version/Due Date: fit content.
// CRP/Launches: fixed width, clipped (no overlap into next column). Comments: fixed width, overflow.
function applyColumnFormatting(sheet) {
  sheet.setColumnWidth(TITLE_IDX + 1, TITLE_COL_WIDTH)
  sheet.getRange(1, TITLE_IDX + 1, sheet.getMaxRows(), 1).setWrap(true)
  FIXED_CLIP_IDXS.forEach(function(idx) {
    sheet.setColumnWidth(idx + 1, FIXED_COL_WIDTH)
    sheet.getRange(1, idx + 1, sheet.getMaxRows(), 1).setWrapStrategy(SpreadsheetApp.WrapStrategy.CLIP)
  })
  FIXED_NOWRAP_IDXS.forEach(function(idx) {
    sheet.setColumnWidth(idx + 1, FIXED_COL_WIDTH)
    sheet.getRange(1, idx + 1, sheet.getMaxRows(), 1).setWrap(false)
  })
  // Flush pending writes first — autoResizeColumn sizes against the sheet's
  // current rendered state, so without this it can measure stale (pre-write)
  // content and leave new values/headers clipped.
  SpreadsheetApp.flush()
  AUTOFIT_IDXS.forEach(function(idx) {
    var col = idx + 1
    sheet.autoResizeColumn(col)
    // autoResizeColumn fits content tightly with no breathing room, which
    // visually clips bold header text — pad a little extra.
    sheet.setColumnWidth(col, sheet.getColumnWidth(col) + 8)
  })
}

function isCancelled(status) {
  var s = String(status || '').trim().toLowerCase()
  return s === 'cancelled' || s === 'canceled' || s === 'on hold'
}

function applyStatusColor(sheet, row, status) {
  var cell = sheet.getRange(row, STATUS_IDX + 1)
  var s = String(status || '').trim().toLowerCase()
  if (s === 'production' || s === 'ready for production' || s === 'cancelled' || s === 'done') {
    cell.setBackground('#EBFDF5').setFontColor('000000')
  } else if (s === 'in progress') {
    cell.setBackground('#FFE59F').setFontColor('#000000')
  } else if (s === 'vqa' || s === 'in planning') {
    cell.setBackground('#BFE1F6').setFontColor('#000000')
  } else if (s === 'system test' || s === 'uat') {
    cell.setBackground('#0953A7').setFontColor('#FFFFFF')
  } else if (s === 'value team review' || s === 'core team review' || s === 'ready for an iteration') {
    cell.setBackground('#E7EAED').setFontColor('#000000')
  } else {
    cell.setBackground(null).setFontColor(null)
  }
}

function isCompleteStatus(status) {
  var s = String(status || '').trim().toLowerCase()
  return s === 'done' || s === 'production'
}

function isTicketRow(rowVals) {
  var tk = String(rowVals[TICKET_IDX] || '').trim()
  var ti = String(rowVals[TITLE_IDX] || '').trim()
  return !!tk && ti !== BLANK_VAL && ti !== '' && ti.toLowerCase() !== 'title'
}

function isRowBlankByA(sheet, row) {
  return String(sheet.getRange(row, 1).getValue() || '').trim() === ''
}

function ensureRowCapacity(sheet, rowNum) {
  var maxRows = sheet.getMaxRows()
  if (rowNum > maxRows) sheet.insertRowsAfter(maxRows, rowNum - maxRows)
}

function copyRowWithFormatting(srcSheet, srcRow, dstSheet, dstRow) {
  var cols = Math.max(srcSheet.getLastColumn(), dstSheet.getLastColumn(), JIRA_COL_COUNT)
  ensureRowCapacity(dstSheet, dstRow)
  srcSheet.getRange(srcRow, 1, 1, cols)
    .copyTo(dstSheet.getRange(dstRow, 1, 1, cols), SpreadsheetApp.CopyPasteType.PASTE_NORMAL, false)
}

// Converts sorted row numbers into contiguous [start,end] groups.
function contiguousRowGroups(rows) {
  if (!rows || !rows.length) return []
  var out = []
  var s = rows[0], p = rows[0]
  for (var i = 1; i < rows.length; i++) {
    var cur = rows[i]
    if (cur === p + 1) {
      p = cur
      continue
    }
    out.push([s, p])
    s = cur
    p = cur
  }
  out.push([s, p])
  return out
}

function deleteDateBlock(sheet, triggerRow) {
  var lr = sheet.getLastRow()
  if (!lr || triggerRow > lr) return
  var colA = sheet.getRange(1, 1, lr, 1).getValues()
  var bb = blockBounds(triggerRow, colA, lr)
  var delStart = triggerRow
  var delEnd = bb.end
  if (delEnd + 1 <= lr && isRowBlankByA(sheet, delEnd + 1)) delEnd += 1
  if (delEnd >= delStart) sheet.deleteRows(delStart, delEnd - delStart + 1)
}

function collectDateTriggers(sheet) {
  var out = []
  var lr = sheet.getLastRow()
  if (!lr) return out
  var cols = Math.max(DATE_COUNT_COL, LEGACY_DATE_LABEL_COL)
  var vals = sheet.getRange(1, 1, lr, cols).getValues()
  for (var i = 0; i < vals.length; i++) {
    var d = parseDate(vals[i][0])
    if (!d) continue
    var meta = blockMetaFromDateLabel(readDateRowLabelFromRow(vals[i]))
    out.push({
      date: d,
      row: i + 1,
      blockType: meta.blockType,
      blockLabel: meta.blockLabel,
      sortKey: meta.sortKey,
    })
  }
  return out
}

function ensureArchiveSheet() {
  var ss = getSpreadsheet()
  var sh = ss.getSheetByName(ARCHIVE_SHEET_NAME)
  if (!sh) sh = ss.insertSheet(ARCHIVE_SHEET_NAME)
  if (sh.isSheetHidden()) sh.showSheet()
  return sh
}

function ensureDateBlock(sheet, dateStr) {
  var lr = sheet.getLastRow()
  var colA = lr ? sheet.getRange(1, 1, lr, 1).getValues() : []
  var rows = rowsForDate(colA, dateStr)
  if (rows.length) return rows[0]

  var dateRow
  if (!lr) {
    dateRow = 1
  } else {
    dateRow = lr + 1
    if (!isRowBlankByA(sheet, lr)) {
      ensureRowCapacity(sheet, lr + 1)
      sheet.insertRowsAfter(lr, 1)
      dateRow = lr + 2
    }
  }

  ensureRowCapacity(sheet, dateRow + 1)
  sheet.getRange(dateRow, 1).setValue(dateStr)
  styleDateRow(sheet, dateRow, 0)
  styleHeader(sheet, dateRow + 1)
  return dateRow
}

function insertDateLabeledBlock(sheet, dateStr, blockType, blockLabel, sortKey, existingBlocks) {
  var marker = normalizeBlockType(blockType) === BLOCK_TYPE_TIME
    ? normalizeBlockLabel(blockType, blockLabel)
    : BLOCK_LABEL_REGULAR

  if (!existingBlocks.length) {
    var firstRow = ensureDateBlock(sheet, dateStr)
    styleDateRow(sheet, firstRow, 0, marker)
    return firstRow
  }

  existingBlocks.sort(function(a, b) { return a.row - b.row })
  var targetMeta = {
    blockType: normalizeBlockType(blockType),
    blockLabel: marker,
    sortKey: normalizeBlockType(blockType) === BLOCK_TYPE_TIME ? +sortKey : 999999,
  }
  var insertBefore = null
  for (var i = 0; i < existingBlocks.length; i++) {
    var rankA = blockSortRank(existingBlocks[i])
    var rankB = blockSortRank(targetMeta)
    var shouldInsert = false
    if (rankA > rankB) {
      shouldInsert = true
    } else if (rankA === rankB && String(existingBlocks[i].blockLabel) > String(targetMeta.blockLabel)) {
      shouldInsert = true
    }
    if (shouldInsert) {
      insertBefore = existingBlocks[i].row
      break
    }
  }

  if (insertBefore !== null) {
    sheet.insertRowsBefore(insertBefore, 2)
    sheet.getRange(insertBefore, 1).setValue(dateStr)
    styleDateRow(sheet, insertBefore, 0, marker)
    styleHeader(sheet, insertBefore + 1)
    return insertBefore
  }

  var lastBlock = existingBlocks[existingBlocks.length - 1]
  var lr = sheet.getLastRow()
  var colA = lr ? sheet.getRange(1, 1, lr, 1).getValues() : []
  var bb = blockBounds(lastBlock.row, colA, lr)
  var insertAfter = bb.end
  sheet.insertRowsAfter(insertAfter, 2)
  var newRow = insertAfter + 1
  sheet.getRange(newRow, 1).setValue(dateStr)
  styleDateRow(sheet, newRow, 0, marker)
  styleHeader(sheet, newRow + 1)
  return newRow
}

function ensureDateLabeledBlock(sheet, dateStr, blockType, blockLabel, sortKey, splitActive) {
  var blocks = collectDateBlocks(sheet)
  var sameDate = blocks.filter(function(b) { return b.date === dateStr })
  var wantType = normalizeBlockType(blockType)
  var wantLabel = normalizeBlockLabel(blockType, blockLabel)

  if (!splitActive) {
    if (sameDate.length) {
      sameDate.sort(function(a, b) { return a.row - b.row })
      for (var i = 0; i < sameDate.length; i++) {
        if (sameDate[i].blockType === BLOCK_TYPE_REGULAR) return sameDate[i].row
      }
      return sameDate[0].row
    }
    return ensureDateBlock(sheet, dateStr)
  }

  for (var j = 0; j < sameDate.length; j++) {
    if (wantType === BLOCK_TYPE_REGULAR) {
      if (sameDate[j].blockType === BLOCK_TYPE_REGULAR) return sameDate[j].row
    } else if (sameDate[j].blockType === BLOCK_TYPE_TIME && sameDate[j].blockLabel === wantLabel) {
      return sameDate[j].row
    }
  }
  return insertDateLabeledBlock(sheet, dateStr, wantType, wantLabel, sortKey, sameDate)
}

function upsertTicketRowFromSource(destSheet, destTriggerRow, ticketKey, srcSheet, srcRow) {
  if (!headerExists(destSheet, destTriggerRow)) {
    destSheet.insertRowsAfter(destTriggerRow, 1)
    styleHeader(destSheet, destTriggerRow + 1)
  }
  var lr = destSheet.getLastRow()
  var colA = destSheet.getRange(1, 1, lr, 1).getValues()
  var bb = blockBounds(destTriggerRow, colA, lr)
  var bd = readBlock(destSheet, bb.start, bb.end, destTriggerRow)

  if (bd.map[ticketKey]) {
    copyRowWithFormatting(srcSheet, srcRow, destSheet, bd.map[ticketKey].rowNum)
    return bd.map[ticketKey].rowNum
  }

  var insertAt = bd.lastReal + 1
  ensureRowCapacity(destSheet, insertAt)
  destSheet.insertRowsAfter(insertAt - 1, 1)
  copyRowWithFormatting(srcSheet, srcRow, destSheet, insertAt)
  return insertAt
}

function finalizeTouchedDates(sheet, touchedDates) {
  var keys = Object.keys(touchedDates || {})
  if (!keys.length) return
  var blocks = collectDateBlocks(sheet)
  var rows = blocks.filter(function(b) { return !!touchedDates[b.date] })
  var hasTimeByDate = {}
  rows.forEach(function(item) {
    if (!hasTimeByDate[item.date]) hasTimeByDate[item.date] = false
    if (item.blockType === BLOCK_TYPE_TIME) hasTimeByDate[item.date] = true
  })
  rows.sort(function(a, b) { return b.row - a.row })
  rows.forEach(function(item) {
    var label = hasTimeByDate[item.date]
      ? (item.blockType === BLOCK_TYPE_TIME ? item.blockLabel : BLOCK_LABEL_REGULAR)
      : 'Total Tickets'
    finaliseDate(sheet, item.row, { dateLabel: label })
  })
}

function runArchiveAndRollback(sourceSheet, issuesByDate, options) {
  options = options || {}
  var sheetOnlyRollback = options.sheetOnlyRollback === true
  var archiveSheet = ensureArchiveSheet()
  var issueByTicket = {}

  if (!sheetOnlyRollback && issuesByDate && typeof issuesByDate === 'object') {
    for (var dKey in issuesByDate) {
      if (!Array.isArray(issuesByDate[dKey])) continue
      issuesByDate[dKey].forEach(function(iss) {
        var tk = String(iss['Ticket Number'] || '').trim()
        if (!tk) return
        issueByTicket[tk] = {
          status: String(iss['Status'] || '').trim(),
          dueDate: parseDate(iss['Due Date']) || String(iss['Due Date'] || '').trim(),
        }
      })
    }
  }

  var archivedCount = 0
  var rollbackMoved = 0
  var rollbackWarnings = []
  var archivedDatesSet = {}
  var touchedSourceDates = {}
  var touchedArchiveDates = {}

  var srcTriggers = collectDateTriggers(sourceSheet).sort(function(a, b) { return b.row - a.row })
  var sourceSplitDates = {}
  srcTriggers.forEach(function(item) {
    if (item.blockType === BLOCK_TYPE_TIME) sourceSplitDates[item.date] = true
  })
  srcTriggers.forEach(function(item) {
    var dateKey = item.date
    var triggerRow = item.row
    if (!parseDate(sourceSheet.getRange(triggerRow, 1).getValue())) return

    var lr = sourceSheet.getLastRow()
    var colA = lr ? sourceSheet.getRange(1, 1, lr, 1).getValues() : []
    var bb = blockBounds(triggerRow, colA, lr)
    if (bb.start > bb.end) {
      deleteDateBlock(sourceSheet, triggerRow)
      touchedSourceDates[dateKey] = true
      return
    }

    var rowCount = bb.end - bb.start + 1
    var vals = sourceSheet.getRange(bb.start, 1, rowCount, Math.max(sourceSheet.getLastColumn(), JIRA_COL_COUNT)).getValues()

    var tickets = []
    var eligible = []
    for (var i = 0; i < vals.length; i++) {
      if (!isTicketRow(vals[i])) continue
      var srcRow = bb.start + i
      var ticket = String(vals[i][TICKET_IDX] || '').trim()
      if (!ticket) continue
      var info = { row: srcRow, ticket: ticket }
      tickets.push(info)
      if (isCompleteStatus(vals[i][STATUS_IDX])) eligible.push(info)
    }

    if (!eligible.length) {
      var remainingNone = countRealInBlock(sourceSheet, triggerRow)
      if (remainingNone === 0) deleteDateBlock(sourceSheet, triggerRow)
      return
    }

    var archiveTrigger = ensureDateLabeledBlock(
      archiveSheet,
      dateKey,
      item.blockType,
      item.blockLabel,
      item.sortKey,
      !!sourceSplitDates[dateKey]
    )
    if (!headerExists(archiveSheet, archiveTrigger)) {
      archiveSheet.insertRowsAfter(archiveTrigger, 1)
      styleHeader(archiveSheet, archiveTrigger + 1)
    }

    var archLr = archiveSheet.getLastRow()
    var archCA = archiveSheet.getRange(1, 1, archLr, 1).getValues()
    var archBB = blockBounds(archiveTrigger, archCA, archLr)
    var archBD = readBlock(archiveSheet, archBB.start, archBB.end, archiveTrigger)

    var hasDuplicate = false
    for (var d = 0; d < eligible.length; d++) {
      if (archBD.map[eligible[d].ticket]) {
        hasDuplicate = true
        break
      }
    }

    // Fast path: every ticket row in the block is archive-eligible and none
    // exists in destination, so copy/delete the whole block in one shot.
    if (tickets.length && eligible.length === tickets.length && !hasDuplicate) {
      var insertAtAll = archBD.lastReal + 1
      ensureRowCapacity(archiveSheet, insertAtAll)
      archiveSheet.insertRowsAfter(insertAtAll - 1, rowCount)
      sourceSheet.getRange(bb.start, 1, rowCount, Math.max(sourceSheet.getLastColumn(), JIRA_COL_COUNT))
        .copyTo(archiveSheet.getRange(insertAtAll, 1, rowCount, Math.max(sourceSheet.getLastColumn(), JIRA_COL_COUNT)), SpreadsheetApp.CopyPasteType.PASTE_NORMAL, false)
      sourceSheet.deleteRows(bb.start, rowCount)

      archivedCount += eligible.length
      archivedDatesSet[dateKey] = true
      touchedSourceDates[dateKey] = true
      touchedArchiveDates[dateKey] = true

      if (countRealInBlock(sourceSheet, triggerRow) === 0) deleteDateBlock(sourceSheet, triggerRow)
      return
    }

    var insertRows = []
    var deleteRows = []
    for (var e = 0; e < eligible.length; e++) {
      var en = eligible[e]
      if (archBD.map[en.ticket]) {
        copyRowWithFormatting(sourceSheet, en.row, archiveSheet, archBD.map[en.ticket].rowNum)
      } else {
        insertRows.push(en.row)
      }
      deleteRows.push(en.row)
      archivedCount++
      archivedDatesSet[dateKey] = true
      touchedSourceDates[dateKey] = true
      touchedArchiveDates[dateKey] = true
    }

    // Insert new rows in one allocation, then copy contiguous source ranges.
    if (insertRows.length) {
      insertRows.sort(function(a, b) { return a - b })
      var insertAt = archBD.lastReal + 1
      ensureRowCapacity(archiveSheet, insertAt)
      archiveSheet.insertRowsAfter(insertAt - 1, insertRows.length)

      var groups = contiguousRowGroups(insertRows)
      var cursor = insertAt
      for (var g = 0; g < groups.length; g++) {
        var gs = groups[g][0]
        var ge = groups[g][1]
        var glen = ge - gs + 1
        sourceSheet.getRange(gs, 1, glen, Math.max(sourceSheet.getLastColumn(), JIRA_COL_COUNT))
          .copyTo(archiveSheet.getRange(cursor, 1, glen, Math.max(sourceSheet.getLastColumn(), JIRA_COL_COUNT)), SpreadsheetApp.CopyPasteType.PASTE_NORMAL, false)
        cursor += glen
      }
    }

    // Delete archived rows in descending contiguous groups to avoid index shift.
    if (deleteRows.length) {
      deleteRows.sort(function(a, b) { return a - b })
      var delGroups = contiguousRowGroups(deleteRows)
      for (var dg = delGroups.length - 1; dg >= 0; dg--) {
        var ds = delGroups[dg][0]
        var de = delGroups[dg][1]
        sourceSheet.deleteRows(ds, de - ds + 1)
      }
    }

    var remaining = countRealInBlock(sourceSheet, triggerRow)
    if (remaining === 0) deleteDateBlock(sourceSheet, triggerRow)
  })

  var archiveTriggers = collectDateTriggers(archiveSheet).sort(function(a, b) { return b.row - a.row })
  archiveTriggers.forEach(function(item) {
    var archiveDate = item.date
    var triggerRow = item.row
    if (!parseDate(archiveSheet.getRange(triggerRow, 1).getValue())) return

    var lr = archiveSheet.getLastRow()
    var colA = lr ? archiveSheet.getRange(1, 1, lr, 1).getValues() : []
    var bb = blockBounds(triggerRow, colA, lr)
    if (bb.start > bb.end) return

    var rowCount = bb.end - bb.start + 1
    var vals = archiveSheet.getRange(bb.start, 1, rowCount, Math.max(archiveSheet.getLastColumn(), JIRA_COL_COUNT)).getValues()

    var byDueDate = {}
    for (var i = 0; i < vals.length; i++) {
      if (!isTicketRow(vals[i])) continue
      var ticket = String(vals[i][TICKET_IDX] || '').trim()
      if (!ticket) continue

      var dueDate = null
      if (sheetOnlyRollback) {
        if (isCompleteStatus(vals[i][STATUS_IDX])) continue
        dueDate = parseDate(vals[i][DUEDATE_IDX]) || String(vals[i][DUEDATE_IDX] || '').trim()
        if (!dueDate) {
          rollbackWarnings.push(ticket + ': missing due date in archive row')
          continue
        }
      } else {
        if (!issueByTicket[ticket]) continue
        if (isCompleteStatus(issueByTicket[ticket].status)) continue
        dueDate = issueByTicket[ticket].dueDate
        if (!dueDate) {
          rollbackWarnings.push(ticket + ': missing Jira due date')
          continue
        }
      }

      var dueKey = blockKey(dueDate, item.blockType, item.blockLabel)
      if (!byDueDate[dueKey]) {
        byDueDate[dueKey] = {
          dueDate: dueDate,
          blockType: item.blockType,
          blockLabel: item.blockLabel,
          sortKey: item.sortKey,
          rows: [],
        }
      }
      byDueDate[dueKey].rows.push({
        archiveRow: bb.start + i,
        ticket: ticket,
      })
    }

    var movedArchiveRows = []
    for (var dueDateKey in byDueDate) {
      var dueGroup = byDueDate[dueDateKey]
      var dueDate = dueGroup.dueDate
      var srcLr = sourceSheet.getLastRow()
      var srcCA = srcLr ? sourceSheet.getRange(1, 1, srcLr, 1).getValues() : []
      var srcRows = rowsForDate(srcCA, dueDate)
      if (!srcRows.length) {
        for (var w = 0; w < dueGroup.rows.length; w++) {
          rollbackWarnings.push(dueGroup.rows[w].ticket + ': source date block ' + dueDate + ' not found')
        }
        continue
      }

      var sourceDateBlocks = collectDateBlocks(sourceSheet)
      var splitActiveDest = dueGroup.blockType === BLOCK_TYPE_TIME
      if (!splitActiveDest) {
        for (var sb = 0; sb < sourceDateBlocks.length; sb++) {
          if (sourceDateBlocks[sb].date === dueDate && sourceDateBlocks[sb].blockType === BLOCK_TYPE_TIME) {
            splitActiveDest = true
            break
          }
        }
      }

      var srcTrigger = ensureDateLabeledBlock(
        sourceSheet,
        dueDate,
        dueGroup.blockType,
        dueGroup.blockLabel,
        dueGroup.sortKey,
        splitActiveDest
      )

      if (!headerExists(sourceSheet, srcTrigger)) {
        sourceSheet.insertRowsAfter(srcTrigger, 1)
        styleHeader(sourceSheet, srcTrigger + 1)
      }

      var destLr = sourceSheet.getLastRow()
      var destCA = sourceSheet.getRange(1, 1, destLr, 1).getValues()
      var destBB = blockBounds(srcTrigger, destCA, destLr)
      var destBD = readBlock(sourceSheet, destBB.start, destBB.end, srcTrigger)

      var insertRows = []
      var items = dueGroup.rows
      for (var k = 0; k < items.length; k++) {
        var it = items[k]
        if (destBD.map[it.ticket]) {
          copyRowWithFormatting(archiveSheet, it.archiveRow, sourceSheet, destBD.map[it.ticket].rowNum)
        } else {
          insertRows.push(it.archiveRow)
        }
        movedArchiveRows.push(it.archiveRow)
        rollbackMoved++
        touchedSourceDates[dueDate] = true
        touchedArchiveDates[archiveDate] = true
      }

      if (insertRows.length) {
        insertRows.sort(function(a, b) { return a - b })
        var insertAt = destBD.lastReal + 1
        ensureRowCapacity(sourceSheet, insertAt)
        sourceSheet.insertRowsAfter(insertAt - 1, insertRows.length)

        var insGroups = contiguousRowGroups(insertRows)
        var cursor = insertAt
        for (var ig = 0; ig < insGroups.length; ig++) {
          var gs = insGroups[ig][0]
          var ge = insGroups[ig][1]
          var glen = ge - gs + 1
          archiveSheet.getRange(gs, 1, glen, Math.max(archiveSheet.getLastColumn(), JIRA_COL_COUNT))
            .copyTo(sourceSheet.getRange(cursor, 1, glen, Math.max(sourceSheet.getLastColumn(), JIRA_COL_COUNT)), SpreadsheetApp.CopyPasteType.PASTE_NORMAL, false)
          cursor += glen
        }
      }
    }

    if (movedArchiveRows.length) {
      movedArchiveRows.sort(function(a, b) { return a - b })
      var movedGroups = contiguousRowGroups(movedArchiveRows)
      for (var mg = movedGroups.length - 1; mg >= 0; mg--) {
        var ds = movedGroups[mg][0]
        var de = movedGroups[mg][1]
        archiveSheet.deleteRows(ds, de - ds + 1)
      }
    }

    if (countRealInBlock(archiveSheet, triggerRow) === 0) deleteDateBlock(archiveSheet, triggerRow)
  })

  finalizeTouchedDates(sourceSheet, touchedSourceDates)
  finalizeTouchedDates(archiveSheet, touchedArchiveDates)

  return {
    archivedCount: archivedCount,
    archivedDates: Object.keys(archivedDatesSet),
    rollbackMoved: rollbackMoved,
    rollbackWarnings: rollbackWarnings,
  }
}

// Applies the full cancelled treatment: grey background across A–G,
// dark text, and clears Content Release Paths + Launches.
function applyCancelledRow(sheet, row, options) {
  var clearPaths = !options || options.clearPaths !== false
  sheet.getRange(row, 1, 1, JIRA_COL_COUNT)
       .setBackground('#bdbdbd')
       .setFontColor('#424242')
  if (clearPaths) {
    sheet.getRange(row, CRPATHS_IDX  + 1).clearContent()
    sheet.getRange(row, LAUNCHES_IDX + 1).clearContent()
  }
}

function writeJiraRow(sheet, row, vals) {
  writeTicketFormula(sheet, row, String(vals[TICKET_IDX]||'').trim())
  sheet.getRange(row, TITLE_IDX+1)    .setValue(String(vals[TITLE_IDX]    ||''))
  sheet.getRange(row, STATUS_IDX+1)   .setValue(String(vals[STATUS_IDX]   ||''))
  writeParentFormula(sheet, row, String(vals[PARENT_IDX]||'').trim())
  sheet.getRange(row, FIXVER_IDX+1)   .setValue(String(vals[FIXVER_IDX]   ||''))
  sheet.getRange(row, DUEDATE_IDX+1)  .setValue(String(vals[DUEDATE_IDX]  ||'')).setNote('')
  sheet.getRange(row, CRPATHS_IDX+1)  .setValue(String(vals[CRPATHS_IDX]  ||''))
  sheet.getRange(row, LAUNCHES_IDX+1) .setValue(String(vals[LAUNCHES_IDX] ||''))
  clearRowStyle(sheet, row)
  if (isCancelled(vals[STATUS_IDX])) {
    applyCancelledRow(sheet, row)
  } else {
    applyStatusColor(sheet, row, vals[STATUS_IDX])
  }
}

function updateJiraFields(sheet, row, vals) {
  sheet.getRange(row, TITLE_IDX+1)    .setValue(String(vals[TITLE_IDX]    ||''))
  sheet.getRange(row, STATUS_IDX+1)   .setValue(String(vals[STATUS_IDX]   ||''))
  writeParentFormula(sheet, row, String(vals[PARENT_IDX]||'').trim())
  sheet.getRange(row, FIXVER_IDX+1)   .setValue(String(vals[FIXVER_IDX]   ||''))
  sheet.getRange(row, DUEDATE_IDX+1)  .setValue(String(vals[DUEDATE_IDX]  ||'')).setNote('')
  sheet.getRange(row, CRPATHS_IDX+1)  .setValue(String(vals[CRPATHS_IDX]  ||''))
  sheet.getRange(row, LAUNCHES_IDX+1) .setValue(String(vals[LAUNCHES_IDX] ||''))
  clearRowStyle(sheet, row)
  if (isCancelled(vals[STATUS_IDX])) {
    applyCancelledRow(sheet, row)
  } else {
    applyStatusColor(sheet, row, vals[STATUS_IDX])
  }
}

// Applies the full rescheduled treatment: light amber-orange across A–G,
// updates the Due Date cell to newDueDate, adds a note, clears paths.
function applyRescheduledRow(sheet, row, newDueDate) {
  sheet.getRange(row, 1, 1, JIRA_COL_COUNT)
       .setBackground('#ffe0b2')
       .setFontColor('#e65100')
  sheet.getRange(row, DUEDATE_IDX + 1)
       .setValue(newDueDate)
       .setNote('Due date changed in Jira — new date not in sheet')
  sheet.getRange(row, CRPATHS_IDX  + 1).clearContent()
  sheet.getRange(row, LAUNCHES_IDX + 1).clearContent()
}

function restoreUserCols(sheet, destRow, fullRow) {
  // Only restore Comments (col E) and beyond — never overwrite with empty
  var commentsVal = fullRow[COMMENTS_IDX]
  if (commentsVal !== undefined && commentsVal !== null && commentsVal !== '') {
    sheet.getRange(destRow, COMMENTS_IDX + 1).setValue(commentsVal)
  }
  // Restore any extra user cols (F+) if they exist and are non-empty
  var lc = Math.max(sheet.getLastColumn(), JIRA_COL_COUNT)
  if (lc > JIRA_COL_COUNT) {
    var extraVals = fullRow.slice(JIRA_COL_COUNT)
    for (var i = 0; i < extraVals.length; i++) {
      if (extraVals[i] !== undefined && extraVals[i] !== null && extraVals[i] !== '') {
        sheet.getRange(destRow, JIRA_COL_COUNT + 1 + i).setValue(extraVals[i])
      }
    }
  }
}

// ── Finalise a date row after all writes ──
// Sets styling, count, header or empty-row as needed
function finaliseDate(sheet, triggerRow, options) {
  options = options || {}
  var count = countRealInBlock(sheet, triggerRow)
  var clearPathsOnCancelled = sheet.getName() !== ARCHIVE_SHEET_NAME
  var dateLabel = options.dateLabel || null
  if (!dateLabel) {
    var existingLabel = readDateRowLabel(sheet, triggerRow)
    var parsed = blockMetaFromDateLabel(existingLabel)
    dateLabel = parsed.blockType === BLOCK_TYPE_TIME ? parsed.blockLabel : (existingLabel.trim() || 'Total Tickets')
  }
  styleDateRow(sheet, triggerRow, count, dateLabel || 'Total Tickets')

  if (count > 0) {
    // Remove stale separator row if present (empty row between date row and header)
    var nextVal = String(sheet.getRange(triggerRow + 1, 1).getValue()).trim()
    if (nextVal === '' && !headerExists(sheet, triggerRow)) {
      // Check if row after the empty row is the header
      var rowAfter = sheet.getLastRow() >= triggerRow + 2
        ? String(sheet.getRange(triggerRow + 2, 1).getValue()).trim()
        : ''
      if (rowAfter.toLowerCase() === 'ticket number') {
        sheet.deleteRow(triggerRow + 1)  // remove the empty separator
      }
    }
    // Ensure header
    if (!headerExists(sheet, triggerRow)) {
      sheet.insertRowsAfter(triggerRow, 1)
    }
    styleHeader(sheet, triggerRow + 1)
    // Clear data row backgrounds
    var lr = sheet.getLastRow()
    var s  = triggerRow + 2
    var e  = lr
    if (s <= lr) {
      var cA = sheet.getRange(s, 1, lr - s + 1, 1).getValues()
      for (var i = 0; i < cA.length; i++)
        if (parseDate(cA[i][0]) !== null) { e = s + i - 1; break }
      if (e >= s) {
        var lc = Math.max(sheet.getLastColumn(), JIRA_COL_COUNT)
        sheet.getRange(s, 1, e - s + 1, lc)
             .setBackground(null).setFontColor(null).setFontWeight('normal')
        // Re-apply status styling row by row after the bulk style reset.
        // finaliseDate runs after all writes, so without this the bulk clear
        // wipes the colors that writeJiraRow/updateJiraFields just set.
        // Cancelled rows get full-row grey + paths cleared; others get
        // status-cell colour only.
        var statusCol = sheet.getRange(s, STATUS_IDX + 1, e - s + 1, 1).getValues()
        for (var si = 0; si < statusCol.length; si++) {
          if (isCancelled(statusCol[si][0])) {
            applyCancelledRow(sheet, s + si, { clearPaths: clearPathsOnCancelled })
          } else {
            applyStatusColor(sheet, s + si, statusCol[si][0])
          }
        }
      }
      // Insert ONE empty separator after block — skip if row e is already empty.
      // blockBounds sets e to the row just before the next date row, so when a
      // separator exists it IS row e (empty). Checking e+1 was wrong: the next
      // date row is never empty, causing a duplicate separator on every move.
      if (e >= s) {
        var eVal = String(sheet.getRange(e, 1).getValue()).trim()
        if (eVal !== '') {
          // Last row of the block is a data row — no separator yet, insert one.
          var sepRow = e + 1
          var lrNow  = sheet.getLastRow()
          if (sepRow <= lrNow) {
            sheet.insertRowsAfter(e, 1)
            sheet.getRange(sepRow, 1, 1, Math.max(sheet.getLastColumn(), JIRA_COL_COUNT))
                 .setBackground(null).setFontColor(null).setFontWeight('normal')
          }
        }
        // else: row e is already empty → separator exists, nothing to do.
      }
    }
  } else {
    // Remove header if present
    if (headerExists(sheet, triggerRow)) sheet.deleteRow(triggerRow + 1)
    // Ensure exactly one empty separator row
    var lr2    = sheet.getLastRow()
    var nextRow = triggerRow + 1
    if (nextRow <= lr2) {
      var nv = String(sheet.getRange(nextRow, 1).getValue()).trim()
      if (nv !== '') {
        // No empty row yet — insert one
        sheet.insertRowsAfter(triggerRow, 1)
        var lc2 = Math.max(sheet.getLastColumn(), JIRA_COL_COUNT)
        sheet.getRange(nextRow, 1, 1, lc2)
             .setBackground(null).setFontColor(null).setFontWeight('normal')
      }
    }
  }
}

// ── CRUD ──

function readAll() {
  try {
    var sheet=getSheet(), data=sheet.getDataRange().getValues()
    if (data.length<=1) return ok({data:[]})
    var rows=[]
    for (var i=1;i<data.length;i++) {
      var obj={}
      COLUMNS.forEach(function(c,j){obj[c]=String(data[i][j]||'')})
      rows.push(obj)
    }
    return ok({data:rows})
  } catch(e){return srvErr(e.message)}
}

function getDates() {
  try { return ok({dates:getAllDates(getSheet())}) }
  catch(e){return srvErr(e.message)}
}

function createRow(data) {
  if (!data||!data['Title']) return badReq('Title required')
  try {
    var sheet=getSheet()
    // Duplicate check
    var all=sheet.getDataRange().getValues()
    var norm=data['Title'].trim().toLowerCase(), dups=[]
    for (var i=0;i<all.length;i++) {
      var t=String(all[i][TITLE_IDX]||'').trim().toLowerCase()
      if (t===norm&&t!=='title'&&t!==BLANK_VAL&&t!=='') dups.push(i+1)
    }
    if (dups.length) {
      dups.forEach(function(r){
        var cur=String(sheet.getRange(r,STATUS_IDX+1).getValue()).trim()
        if (!cur.endsWith(DUP_SUFFIX)) sheet.getRange(r,STATUS_IDX+1).setValue(cur+DUP_SUFFIX)
      })
      return ok({action:'updated', message:'Duplicate status updated at '+dups.length+' row(s)'})
    }
    var lr=sheet.getLastRow()
    var colA=lr?sheet.getRange(1,1,lr,1).getValues():[]
    var allDates=getAllDates(sheet)
    if (!allDates.length) return respond({success:false,error:'No date cells in column A',code:403})
    var csp = splitPaths(data['Content Release Paths'] || '')
    var vals=[data['Ticket Number']||'',data['Title']||'',data['Status']||'active',data['Parent Ticket Number']||'',data['Fix Version']||'',parseDate(data['Due Date'])||data['Due Date']||'',csp.crp,csp.launches,'']
    var inserted=[]
    // Bottom-up
    var triggers=[]
    allDates.forEach(function(d){rowsForDate(colA,d).forEach(function(r){triggers.push(r)})})
    triggers.sort(function(a,b){return b-a})
    triggers.forEach(function(tr){
      // Ensure header
      if (!headerExists(sheet,tr)){sheet.insertRowsAfter(tr,1);styleHeader(sheet,tr+1)}
      var lr2=sheet.getLastRow()
      var cA=sheet.getRange(1,1,lr2,1).getValues()
      var bb=blockBounds(tr,cA,lr2)
      var bd=readBlock(sheet,bb.start,bb.end,tr)
      sheet.insertRowsAfter(bd.lastReal,1)
      writeJiraRow(sheet,bd.lastReal+1,vals)
      inserted.push(bd.lastReal+1)
    })
    // Re-read triggers and finalise
    var lr3=sheet.getLastRow()
    var cA3=sheet.getRange(1,1,lr3,1).getValues()
    triggers.forEach(function(tr){
      // find fresh row
      for (var i=0;i<cA3.length;i++)
        if (parseDate(cA3[i][0])===allDates[0]||(function(){
          for(var d=0;d<allDates.length;d++) if(parseDate(cA3[i][0])===allDates[d]&&i+1===tr) return true; return false
        })()) break
      finaliseDate(sheet,tr)
    })
    applyColumnFormatting(sheet)
    applyColumnFormatting(ensureArchiveSheet())
    return ok({action:'created',message:'Inserted at '+inserted.length+' location(s)',insertedAtRows:inserted})
  } catch(e){return srvErr(e.message)}
}

function updateRow(ticket, data) {
  if (!ticket) return badReq('Ticket Number required')
  try {
    var sheet=getSheet(), all=sheet.getDataRange().getValues()
    var row=-1
    for (var i=0;i<all.length;i++) if(String(all[i][TICKET_IDX]).trim()===String(ticket).trim()){row=i+1;break}
    if (row===-1) return respond({success:false,error:'Not found: '+ticket,code:404})
    var ex=sheet.getRange(row,1,1,JIRA_COL_COUNT).getValues()[0]
    var sp = data['Content Release Paths'] !== undefined
      ? splitPaths(data['Content Release Paths'])
      : { crp: ex[CRPATHS_IDX], launches: ex[LAUNCHES_IDX] }
    var nv=[ex[TICKET_IDX],
      data['Title']    !==undefined?data['Title']    :ex[TITLE_IDX],
      data['Status']   !==undefined?data['Status']   :ex[STATUS_IDX],
      data['Parent Ticket Number'] !==undefined?data['Parent Ticket Number']:ex[PARENT_IDX],
      data['Fix Version']          !==undefined?data['Fix Version']         :ex[FIXVER_IDX],
      data['Due Date'] !==undefined?(parseDate(data['Due Date'])||data['Due Date']):ex[DUEDATE_IDX],
      sp.crp,
      sp.launches,
      ex[COMMENTS_IDX]]
    updateJiraFields(sheet,row,nv)
    applyColumnFormatting(sheet)
    return ok({message:'Updated',ticket:ticket})
  } catch(e){return srvErr(e.message)}
}

function deleteRow(ticket) {
  if (!ticket) return badReq('Ticket Number required')
  try {
    var sheet=getSheet(), all=sheet.getDataRange().getValues()
    var row=-1
    for (var i=0;i<all.length;i++) if(String(all[i][TICKET_IDX]).trim()===String(ticket).trim()){row=i+1;break}
    if (row===-1) return respond({success:false,error:'Not found: '+ticket,code:404})
    sheet.deleteRow(row)
    return ok({message:'Deleted '+ticket})
  } catch(e){return srvErr(e.message)}
}

function archiveRows() {
  try {
    var sourceSheet = getSheet()
    var archiveInfo = runArchiveAndRollback(sourceSheet, null, { sheetOnlyRollback: true })
    applyColumnFormatting(sourceSheet)
    applyColumnFormatting(ensureArchiveSheet())
    return ok({
      message: 'Archive complete',
      stats: {
        archivedCount: archiveInfo.archivedCount || 0,
        archivedDates: archiveInfo.archivedDates || [],
        rollbackMoved: archiveInfo.rollbackMoved || 0,
        rollbackWarnings: archiveInfo.rollbackWarnings || [],
      },
    })
  } catch(e) { return srvErr(e.message) }
}

// ── syncJira — single global pass ──
function syncJira(issuesByDate, options) {
  if (!issuesByDate||typeof issuesByDate!=='object') return badReq('issuesByDate required')
  try {
    options = options || {}
    var mode = String(options.mode || 'full')
    var isLiteArchive = mode === 'liteArchive'
    var sheet=getSheet()

    var splitDates = {}
    for (var skDate in issuesByDate) {
      if (!Array.isArray(issuesByDate[skDate])) continue
      for (var sd = 0; sd < issuesByDate[skDate].length; sd++) {
        var rawType = normalizeBlockType(issuesByDate[skDate][sd]['Time Block Type'])
        if (rawType === BLOCK_TYPE_TIME) {
          splitDates[skDate] = true
          break
        }
      }
    }

    // Step 1: build globalMap — ticket → {blockDate, blockType, blockLabel, triggerRow, rowNum, jiraVals, fullRow}
    var globalMap={}
    var snapLr=sheet.getLastRow()
    var snapCA=snapLr?sheet.getRange(1,1,snapLr,1).getValues():[]
    var snapBlocks = collectDateBlocks(sheet)
    for (var bi = 0; bi < snapBlocks.length; bi++) {
      var block = snapBlocks[bi]
      var tr = block.row
      var bb = blockBounds(tr, snapCA, snapLr)
      var bd = readBlock(sheet, bb.start, bb.end, tr)
      for (var tk in bd.map) {
        globalMap[tk] = {
          blockDate: block.date,
          blockType: block.blockType,
          blockLabel: block.blockLabel,
          sortKey: block.sortKey,
          triggerRow: tr,
          rowNum: bd.map[tk].rowNum,
          jiraVals: bd.map[tk].jiraVals,
          fullRow: bd.map[tk].fullRow,
        }
      }
    }

    // Step 2: classify
    var updateBatch=[], moveBatch=[], insertBatch={}

    for (var dateKey in issuesByDate) {
      var issues=issuesByDate[dateKey]
      if (!Array.isArray(issues)) continue

      for (var ii=0;ii<issues.length;ii++) {
        var iss=issues[ii]
        var ticket  =String(iss['Ticket Number']           ||'').trim()
        var title   =String(iss['Title']                   ||'').trim()
        var status  =String(iss['Status']                  ||'unknown').trim()
        var parent  =String(iss['Parent Ticket Number']    ||'').trim()
        var fixVer  =String(iss['Fix Version']             ||'').trim()
        var rawDue  =String(iss['Due Date']                ||'').trim()
        var sp      =splitPaths(iss['Content Release Paths']||'')
        var normDue =parseDate(rawDue)||rawDue
        var rawType = normalizeBlockType(iss['Time Block Type'])
        var rawLabel = normalizeBlockLabel(rawType, iss['Time Block Label'])
        var rawSort = +iss['Time Sort Key']
        if (!isFinite(rawSort)) rawSort = 999999
        var targetType = splitDates[dateKey] ? rawType : BLOCK_TYPE_REGULAR
        var targetLabel = targetType === BLOCK_TYPE_TIME ? rawLabel : BLOCK_LABEL_REGULAR
        var targetSort = targetType === BLOCK_TYPE_TIME ? rawSort : 999999
        if (!ticket) continue

        var ex=globalMap[ticket]
        if (!ex) {
          var insKey = blockKey(dateKey, targetType, targetLabel)
          if (!insertBatch[insKey]) insertBatch[insKey]=[]
          insertBatch[insKey].push({
            date: dateKey,
            blockType: targetType,
            blockLabel: targetLabel,
            sortKey: targetSort,
            splitActive: !!splitDates[dateKey],
            values: [ticket,title,status,parent,fixVer,normDue,sp.crp,sp.launches,''],
          })
          continue
        }

        if (ex.blockDate!==dateKey || ex.blockType!==targetType || (targetType === BLOCK_TYPE_TIME && ex.blockLabel !== targetLabel)) {
          moveBatch.push({
            ticket:ticket,
            newVals:[ticket,title,status,parent,fixVer,normDue,sp.crp,sp.launches,''],
            sourceRowNum:ex.rowNum,
            sourceTrigger:ex.triggerRow,
            sourceDate:ex.blockDate,
            sourceBlockType:ex.blockType,
            sourceBlockLabel:ex.blockLabel,
            destDate:dateKey,
            destBlockType:targetType,
            destBlockLabel:targetLabel,
            destSortKey:targetSort,
            fullRow:ex.fullRow,
            splitActive: !!splitDates[dateKey],
          })
          continue
        }

        var xv=ex.jiraVals
        var normEx=parseDate(xv[DUEDATE_IDX])||String(xv[DUEDATE_IDX]||'').trim()
        if (String(xv[TITLE_IDX]    ||'').trim()!==title||
            String(xv[STATUS_IDX]   ||'').trim()!==status||normEx!==normDue||
            String(xv[PARENT_IDX]   ||'').trim()!==parent||
            String(xv[FIXVER_IDX]   ||'').trim()!==fixVer||
            String(xv[CRPATHS_IDX]  ||'').trim()!==sp.crp||
            String(xv[LAUNCHES_IDX] ||'').trim()!==sp.launches)
          updateBatch.push({
            rowNum:ex.rowNum,
            newVals:[ticket,title,status,parent,fixVer,normDue,sp.crp,sp.launches,xv[COMMENTS_IDX]||''],
            triggerRow:ex.triggerRow,
            date: ex.blockDate,
            blockType: ex.blockType,
            blockLabel: ex.blockLabel,
          })
      }
    }

    // Compute stale keys — ticket keys that exist in the sheet but were not
    // returned by any date's Jira query this sync (cancelled, due date changed
    // to a date not in the sheet, etc.).  Returned to the worker so it can
    // call Jira individually and apply targeted reconciliation.
    var touchedKeys = {}
    for (var dtk in issuesByDate) {
      if (!Array.isArray(issuesByDate[dtk])) continue
      issuesByDate[dtk].forEach(function(iss) {
        var tk = String(iss['Ticket Number'] || '').trim()
        if (tk) touchedKeys[tk] = true
      })
    }
    var staleKeys = []
    for (var sk in globalMap) {
      if (!touchedKeys[sk]) staleKeys.push({ key: sk, blockDate: globalMap[sk].blockDate })
    }

    var affectedDates={}, totalU=0, totalM=0, totalI=0

    // 3a: updates
    for (var u=0;u<updateBatch.length;u++) {
      updateJiraFields(sheet,updateBatch[u].rowNum,updateBatch[u].newVals)
      affectedDates[updateBatch[u].date || (parseDate(sheet.getRange(updateBatch[u].triggerRow,1).getValue())||'')] = true
      totalU++
    }

    // 3b: move deletes bottom-up
    moveBatch.sort(function(a,b){return b.sourceRowNum-a.sourceRowNum})
    for (var mv=0;mv<moveBatch.length;mv++) {
      sheet.deleteRow(moveBatch[mv].sourceRowNum)
      affectedDates[moveBatch[mv].sourceDate]=true
    }

    // 3c: move inserts into destination
    if (moveBatch.length) {
      var byDest={}
      moveBatch.forEach(function(m){
        var dk = blockKey(m.destDate, m.destBlockType, m.destBlockLabel)
        if (!byDest[dk]) byDest[dk]=[]
        byDest[dk].push(m)
      })
      for (var mdKey in byDest) {
        var items=byDest[mdKey]
        var first=items[0]
        var dtr=ensureDateLabeledBlock(sheet, first.destDate, first.destBlockType, first.destBlockLabel, first.destSortKey, !!first.splitActive)
        if (!headerExists(sheet,dtr)){sheet.insertRowsAfter(dtr,1);styleHeader(sheet,dtr+1)}
        var lr2=sheet.getLastRow(),cA2=sheet.getRange(1,1,lr2,1).getValues()
        var dbb=blockBounds(dtr,cA2,lr2), dbd=readBlock(sheet,dbb.start,dbb.end,dtr)
        sheet.insertRowsAfter(dbd.lastReal,items.length)
        items.forEach(function(m,mi){
          writeJiraRow(sheet,dbd.lastReal+1+mi,m.newVals)
          restoreUserCols(sheet,dbd.lastReal+1+mi,m.fullRow)
        })
        affectedDates[first.destDate]=true
        totalM+=items.length
      }
    }

    // 3d: new inserts
    for (var insKey in insertBatch) {
      var insItems=insertBatch[insKey]
      if (!insItems.length) continue
      var meta=insItems[0]
      var itr=ensureDateLabeledBlock(sheet, meta.date, meta.blockType, meta.blockLabel, meta.sortKey, !!meta.splitActive)
      if (!headerExists(sheet,itr)){sheet.insertRowsAfter(itr,1);styleHeader(sheet,itr+1)}
      var ilr=sheet.getLastRow(),iCA=sheet.getRange(1,1,ilr,1).getValues()
      var ibb=blockBounds(itr,iCA,ilr), ibd=readBlock(sheet,ibb.start,ibb.end,itr)
      sheet.insertRowsAfter(ibd.lastReal,insItems.length)
      insItems.forEach(function(item,ri){writeJiraRow(sheet,ibd.lastReal+1+ri,item.values)})
      affectedDates[meta.date]=true
      totalI+=insItems.length
    }

    if (!isLiteArchive) {
      // Full sync: restyle all date blocks for sheet-wide consistency.
      collectDateBlocks(sheet).forEach(function(b){ affectedDates[b.date]=true })
    }

    // 3f: finalise every affected date block bottom-up.
    var finalLr=sheet.getLastRow()
    if (finalLr>0) {
      var finalBlocks = collectDateBlocks(sheet)
      var toFinalise=[]
      for (var fb=0; fb<finalBlocks.length; fb++) {
        if (affectedDates[finalBlocks[fb].date]) toFinalise.push(finalBlocks[fb])
      }
      toFinalise.sort(function(a,b){return b.row-a.row})
      toFinalise.forEach(function(item){
        var label = splitDates[item.date]
          ? (item.blockType === BLOCK_TYPE_TIME ? item.blockLabel : BLOCK_LABEL_REGULAR)
          : 'Total Tickets'
        finaliseDate(sheet, item.row, { dateLabel: label })
      })
    }

    applyColumnFormatting(sheet)

    var totalSkip=0
    for (var dk in issuesByDate)
      if (Array.isArray(issuesByDate[dk])) totalSkip+=issuesByDate[dk].length
    totalSkip=Math.max(0,totalSkip-totalU-totalM-totalI)

    return ok({message:isLiteArchive ? 'Lite sync complete' : 'Sync complete',
      stats:{updated:totalU,moved:totalM,inserted:totalI,skipped:totalSkip},
      staleKeys:staleKeys,
      mode: mode})
  } catch(e){return srvErr(e.message)}
}

// ── Reconciliation — post-sync stale ticket cleanup ───────────────────────
// Called by the worker after it has individually queried Jira for each stale
// ticket (one that existed in the sheet but wasn't returned by any date query).
//
//  cancelled   — [{key, blockDate, newStatus}]
//    → Status cell updated to newStatus and coloured grey.
//
//  rescheduled — [{key, blockDate, newDueDate}]
//    → Full row flagged amber-orange (#ffe0b2 / #e65100). Due Date updated
//      to newDueDate with a note. Content Release Paths + Launches cleared.
//      Row stays in the old block until the user adds the new date to the sheet.
function applyReconciliation(cancelled, rescheduled) {
  try {
    var sheet   = getSheet()
    var lastRow = sheet.getLastRow()
    var nCancelled = 0, nRescheduled = 0

    if (!lastRow) return ok({ stats: { cancelled: 0, rescheduled: 0 } })

    // Build ticket key → sheet row index from col A.
    // getValues() returns the computed display value of HYPERLINK formulas,
    // so ticket keys are read back correctly.
    var colAVals = sheet.getRange(1, 1, lastRow, 1).getValues()
    var keyToRow = {}
    for (var i = 0; i < colAVals.length; i++) {
      var val = String(colAVals[i][0] || '').trim()
      if (!val) continue
      if (parseDate(val) !== null) continue
      if (val.toLowerCase() === COLUMNS[TICKET_IDX].toLowerCase()) continue
      keyToRow[val] = i + 1
    }

    if (Array.isArray(cancelled)) {
      cancelled.forEach(function(item) {
        var row = keyToRow[item.key]
        if (!row) return
        sheet.getRange(row, STATUS_IDX + 1).setValue(item.newStatus || 'Cancelled')
        applyCancelledRow(sheet, row)
        nCancelled++
      })
    }

    if (Array.isArray(rescheduled)) {
      rescheduled.forEach(function(item) {
        var row = keyToRow[item.key]
        if (!row) return
        applyRescheduledRow(sheet, row, item.newDueDate)
        nRescheduled++
      })
    }

    return ok({ stats: { cancelled: nCancelled, rescheduled: nRescheduled } })
  } catch(e) { return srvErr(e.message) }
}

// ── Snapshot helpers ──────────────────────────────────────────────────────
//
//  takeSnapshot  — copies Sheet1 (values + formatting) into a hidden
//                  _snapshot tab before the syncJira write begins.
//  revertSnapshot — restores Sheet1 from _snapshot, then deletes the tab.
//  deleteSnapshot — deletes the _snapshot tab after a successful sync.
//
//  Called by the extension's background worker:
//    takeSnapshot   → GET  ?action=takeSnapshot
//    revertSnapshot → POST body.action='revertSnapshot'
//    deleteSnapshot → POST body.action='deleteSnapshot'

var SNAPSHOT_SHEET = '_snapshot'

function takeSnapshot() {
  try {
    var ss    = getSpreadsheet()
    var sheet = getSheet()

    // Remove any stale snapshot from a previous aborted run
    var existing = ss.getSheetByName(SNAPSHOT_SHEET)
    if (existing) ss.deleteSheet(existing)

    var lr = sheet.getLastRow()
    var lc = sheet.getLastColumn()

    // Create a hidden snapshot sheet
    var snap = ss.insertSheet(SNAPSHOT_SHEET)
    snap.hideSheet()

    if (lr > 0 && lc > 0) {
      var src = sheet.getRange(1, 1, lr, lc)
      var dst = snap.getRange(1, 1, lr, lc)
      // PASTE_NORMAL copies values, formulas, and all formatting
      src.copyTo(dst, SpreadsheetApp.CopyPasteType.PASTE_NORMAL, false)
    }

    return ok({ message: 'Snapshot taken', rows: lr, cols: lc })
  } catch(e) { return srvErr(e.message) }
}

function revertSnapshot() {
  try {
    var ss    = getSpreadsheet()
    var sheet = getSheet()
    var snap  = ss.getSheetByName(SNAPSHOT_SHEET)

    if (!snap) {
      // Cancel happened before snapshot was taken — nothing to revert
      return ok({ message: 'No snapshot found — no changes were made', noSnapshot: true })
    }

    var snapLr = snap.getLastRow()
    var snapLc = snap.getLastColumn()
    var currLr = sheet.getLastRow()

    // 1. Clear Sheet1 (values + formatting)
    sheet.clear()

    // 2. Delete rows that were added during the partial sync so the
    //    sheet dimensions match the snapshot exactly
    var sheetLrNow = sheet.getMaxRows()
    var targetRows = Math.max(snapLr, 1)
    if (sheetLrNow > targetRows) {
      sheet.deleteRows(targetRows + 1, sheetLrNow - targetRows)
    }

    // 3. Restore from snapshot (values + formatting + formulas)
    if (snapLr > 0 && snapLc > 0) {
      var src = snap.getRange(1, 1, snapLr, snapLc)
      var dst = sheet.getRange(1, 1, snapLr, snapLc)
      src.copyTo(dst, SpreadsheetApp.CopyPasteType.PASTE_NORMAL, false)
    }

    // 4. Delete the snapshot tab
    ss.deleteSheet(snap)

    return ok({ message: 'Sheet reverted to pre-sync state', rows: snapLr })
  } catch(e) { return srvErr(e.message) }
}

function deleteSnapshot() {
  try {
    var ss   = getSpreadsheet()
    var snap = ss.getSheetByName(SNAPSHOT_SHEET)
    if (snap) ss.deleteSheet(snap)
    return ok({ message: 'Snapshot deleted' })
  } catch(e) { return srvErr(e.message) }
}

// ── Entry points ──
function doGet(e) {
  var key = e.parameter && e.parameter.key ? e.parameter.key : null
  if (!validateKey(key)) return unauth()
  _spreadsheetId = (e.parameter && e.parameter.spreadsheetId) || null
  _sheetName     = (e.parameter && e.parameter.sheetName)     || null
  switch ((e.parameter && e.parameter.action) || 'read') {
    case 'read':         return readAll()
    case 'getDates':     return getDates()
    case 'takeSnapshot': return takeSnapshot()
    default:             return badReq('Unknown action')
  }
}

function doPost(e) {
  var body = {}
  try { body = JSON.parse(e.postData.contents) } catch(_) { return badReq('Invalid JSON') }
  if (!validateKey(body.key || null)) return unauth()
  _spreadsheetId = body.spreadsheetId || null
  _sheetName     = body.sheetName     || null
  switch (body.action) {
    case 'create':         return createRow(body.data)
    case 'update':         return updateRow(body.id, body.data || {})
    case 'delete':         return deleteRow(body.id)
    case 'archive':        return archiveRows()
    case 'syncJira':            return syncJira(body.issuesByDate, { mode: body.mode })
    case 'applyReconciliation': return applyReconciliation(body.cancelled, body.rescheduled)
    case 'revertSnapshot':      return revertSnapshot()
    case 'deleteSnapshot': return deleteSnapshot()
    default:               return badReq('Unknown action')
  }
}